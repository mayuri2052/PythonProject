from MBBank import BankAccount
class CurrentAccount(BankAccount):


    def __init__(self, initialAmount):
        super().__init__(initialAmount)
        print("Congratulations... Your Current Account has been created")

    def curwithdrwal(self, amount):
        amount += 200
        print("Charge 200 is applicable for every withdraw")
        self.withdraw(amount)
