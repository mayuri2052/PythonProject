print("Welcome to MB bank ")


class BankAccount:
    _currentBalance = None

    def __init__(self, initialAmount):
        self._currentBalance = initialAmount
        # print("Congratulations... Your Account has been created")

    def displaybalance(self):
        print("Your current balance is "+str(self._currentBalance))

    def deposit(self, amount):
        self._currentBalance += amount
        print(str(amount) + " is deposited in your account")

    def checkbalance(self, amount):
         if self._currentBalance < amount:
             return False
         else:
             return True

    def withdraw(self, amount):
        if self.checkbalance(amount):
            self._currentBalance -= amount
            print(str(amount) + " is withdrawl from your account")
        else:
            print("Insufficient amount in account")

    def transfer(self, amount, bankAccount):
        self.withdraw(amount)
        bankAccount.deposit(amount)




